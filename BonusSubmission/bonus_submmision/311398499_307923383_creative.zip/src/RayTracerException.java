package RenderScene;

public class RayTracerException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RayTracerException(String msg) {  super(msg); }
}
